<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\Prototype\BadClasses;

class MissingParent extends MissingClass
{
}
