CHANGELOG
=========

3.3.0
-----

* Added `PropertyInfoPass`
