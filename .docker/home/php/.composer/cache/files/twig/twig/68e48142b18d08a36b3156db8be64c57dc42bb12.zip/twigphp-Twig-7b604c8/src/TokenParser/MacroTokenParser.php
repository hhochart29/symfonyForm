<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Macro');

if (\false) {
    class MacroTokenParser extends \Twig_TokenParser_Macro
    {
    }
}
