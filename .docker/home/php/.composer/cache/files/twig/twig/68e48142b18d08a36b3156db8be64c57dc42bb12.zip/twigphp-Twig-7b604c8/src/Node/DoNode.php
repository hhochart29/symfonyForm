<?php

namespace Twig\Node;

class_exists('Twig_Node_Do');

if (\false) {
    class DoNode extends \Twig_Node_Do
    {
    }
}
