<?php

$container->loadFromExtension('twig', array());
