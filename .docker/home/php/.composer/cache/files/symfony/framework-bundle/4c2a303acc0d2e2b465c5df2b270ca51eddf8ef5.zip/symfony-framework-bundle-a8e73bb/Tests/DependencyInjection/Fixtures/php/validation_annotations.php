<?php

$container->loadFromExtension('framework', array(
    'secret' => 's3cr3t',
    'validation' => array(
        'enabled' => true,
        'enable_annotations' => true,
    ),
));
