---
title: Download / Installation
---

## Download / Installation

The suggested installation method is via [composer](https://getcomposer.org/).

```sh
php composer.phar require ocramius/proxy-manager:1.0.*
```
