<?php

$container->loadFromExtension('framework', array(
    'web_link' => array('enabled' => true),
));
