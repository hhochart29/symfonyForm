<?php

namespace App\Entity;

class User
{
    private $id;

    public function getId(): ?int
    {
        // custom comment
        return $this->id;
    }
}
