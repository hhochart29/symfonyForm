<?php

$container->loadFromExtension('framework', array(
    'translator' => false,
    'templating' => array(
        'engines' => array('php'),
    ),
));
