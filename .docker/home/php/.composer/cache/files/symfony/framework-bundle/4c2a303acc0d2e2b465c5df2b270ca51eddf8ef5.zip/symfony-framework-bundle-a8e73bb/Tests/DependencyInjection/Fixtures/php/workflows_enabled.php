<?php

$container->loadFromExtension('framework', array(
    'workflows' => null,
));
