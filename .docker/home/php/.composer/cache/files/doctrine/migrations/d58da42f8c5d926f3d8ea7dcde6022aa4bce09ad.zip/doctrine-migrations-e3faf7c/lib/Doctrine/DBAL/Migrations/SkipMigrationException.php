<?php

namespace Doctrine\DBAL\Migrations;

class SkipMigrationException extends MigrationException
{
}
