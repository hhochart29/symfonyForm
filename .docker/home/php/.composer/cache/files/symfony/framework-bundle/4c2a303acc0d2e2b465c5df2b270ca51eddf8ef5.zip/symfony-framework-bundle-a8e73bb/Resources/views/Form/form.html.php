<?php echo $view['form']->start($form) ?>
    <?php echo $view['form']->widget($form) ?>
<?php echo $view['form']->end($form) ?>
