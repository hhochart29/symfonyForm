<?php

$container->loadFromExtension('framework', array(
    'validation' => array(
        'translation_domain' => 'messages',
    ),
));
