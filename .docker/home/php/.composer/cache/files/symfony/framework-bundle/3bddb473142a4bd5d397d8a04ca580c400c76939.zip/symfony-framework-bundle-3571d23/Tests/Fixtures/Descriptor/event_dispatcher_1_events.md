# Registered listeners

## event1

### Listener 1

- Type: `function`
- Name: `global_function`
- Priority: `255`

### Listener 2

- Type: `closure`
- Priority: `-1`

## event2

### Listener 1

- Type: `object`
- Name: `Symfony\Bundle\FrameworkBundle\Tests\Console\Descriptor\CallableClass`
- Priority: `0`
