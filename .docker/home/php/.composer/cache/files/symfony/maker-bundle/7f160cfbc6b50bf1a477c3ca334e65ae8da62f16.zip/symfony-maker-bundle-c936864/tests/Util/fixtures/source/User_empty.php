<?php

namespace App\Entity;

class User {}
