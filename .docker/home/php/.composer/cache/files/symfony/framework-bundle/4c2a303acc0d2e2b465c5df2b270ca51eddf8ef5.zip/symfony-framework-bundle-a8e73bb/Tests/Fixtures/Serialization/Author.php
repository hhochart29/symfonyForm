<?php

namespace Symfony\Bundle\FrameworkBundle\Tests\Fixtures\Serialization;

class Author
{
    public $gender;
}
