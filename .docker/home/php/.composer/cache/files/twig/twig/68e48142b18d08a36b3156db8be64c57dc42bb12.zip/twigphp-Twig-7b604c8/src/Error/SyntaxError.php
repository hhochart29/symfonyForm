<?php

namespace Twig\Error;

class_exists('Twig_Error_Syntax');

if (\false) {
    class SyntaxError extends \Twig_Error_Syntax
    {
    }
}
