<?php

namespace App\Entity;

class User
{
    private $fooProp;
}
