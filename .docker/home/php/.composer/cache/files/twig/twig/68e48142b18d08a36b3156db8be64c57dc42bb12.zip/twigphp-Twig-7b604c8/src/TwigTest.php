<?php

namespace Twig;

class_exists('Twig_SimpleTest');

if (\false) {
    class TwigTest extends \Twig_SimpleTest
    {
    }
}
