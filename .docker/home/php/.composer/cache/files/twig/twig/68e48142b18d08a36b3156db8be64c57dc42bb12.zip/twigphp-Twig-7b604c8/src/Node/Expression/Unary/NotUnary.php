<?php

namespace Twig\Node\Expression\Unary;

class_exists('Twig_Node_Expression_Unary_Not');

if (\false) {
    class NotUnary extends \Twig_Node_Expression_Unary_Not
    {
    }
}
