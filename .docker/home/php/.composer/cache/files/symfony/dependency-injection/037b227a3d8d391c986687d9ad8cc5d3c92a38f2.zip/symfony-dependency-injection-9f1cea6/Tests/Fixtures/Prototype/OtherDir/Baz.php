<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\Prototype\OtherDir;

class Baz
{
}
