<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\includes\HotPath;

trait T1
{
}
