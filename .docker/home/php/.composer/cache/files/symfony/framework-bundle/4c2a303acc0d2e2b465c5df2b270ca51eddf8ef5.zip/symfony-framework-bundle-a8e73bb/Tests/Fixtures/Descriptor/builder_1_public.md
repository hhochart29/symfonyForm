Public services
===============

Definitions
-----------

### definition_1

- Class: `Full\Qualified\Class1`
- Public: yes
- Synthetic: no
- Lazy: yes
- Shared: yes
- Abstract: yes
- Autowired: no
- Autoconfigured: no
- Factory Class: `Full\Qualified\FactoryClass`
- Factory Method: `get`


Aliases
-------

### alias_1

- Service: `service_1`
- Public: yes


Services
--------

- `service_container`: `Symfony\Component\DependencyInjection\ContainerBuilder`
