<?php

$container->loadFromExtension('framework', array(
    'session' => array(
        'handler_id' => null,
    ),
));
