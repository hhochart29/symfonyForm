<?php

namespace Symfony\Bundle\MakerBundle\Tests\tmp\current_project\src\Entity;

class XOther
{
    private $id;

    public function getId(): ?int
    {
        return $this->id;
    }
}
