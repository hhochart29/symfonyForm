<?php return array (
  'bundle:controller:name.format.engine' => __DIR__.'/../path/to/template.html.twig',
);
