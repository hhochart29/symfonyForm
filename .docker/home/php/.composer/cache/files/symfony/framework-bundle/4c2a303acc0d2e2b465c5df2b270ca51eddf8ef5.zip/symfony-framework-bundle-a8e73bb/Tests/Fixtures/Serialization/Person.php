<?php

namespace Symfony\Bundle\FrameworkBundle\Tests\Fixtures\Serialization;

class Person
{
    public $gender;
}
