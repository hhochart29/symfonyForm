CHANGELOG
=========

3.4.0
-----

 * WebServer can now use '*' as a wildcard to bind to 0.0.0.0 (INADDR_ANY)

3.3.0
-----

 * Added bundle
